//Define data
let data = [
    { name: 'Rainne'    , rating: 8 },
    { name: 'Buddy'    , rating: 7 },
    { name: 'Paddy'   , rating: 3 },
    { name: 'Sticky', rating: 9 },
    { name: 'Midnight'  , rating: 5 },
    { name: 'Leo'  , rating: 6 }
  ];